//
//  InnerViewController.swift
//  Test
//
//  Created by kurupareshan pathmanathan on 4/8/21.
//  Copyright © 2021 kurupareshan pathmanathan. All rights reserved.
//

//InnerViewController
import UIKit
import SnapKit
import Alamofire

class InnerViewController: UIViewController, UNUserNotificationCenterDelegate {
   
    let userNotificationCenter = UNUserNotificationCenter.current()
    
    let year = UITextField()
    let month = UITextField()
    let day = UITextField()
    let hour = UITextField()
    let minute = UITextField()
    let second = UITextField()
    let submit = UIButton()
    let timeText = UILabel()
    let URL_USER_REGISTER = "http://127.0.0.1/test5/index.php"
    
    struct myData : Decodable {
        let year : String
        let month : String
        let day : String
        let hour : String
        let minute : String
        let second : String
    }
    
    var mydata = [myData]()
    
    var timer:Timer = Timer()
    var count:Int = 0
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.view.backgroundColor = .white
        
        
        userNotificationCenter.delegate = self
        self.requestNotificationAuthorization()
        
        self.view.addSubview(year)
        year.translatesAutoresizingMaskIntoConstraints = false
        year.layer.borderColor = UIColor.black.cgColor
        year.layer.borderWidth = 1
        year.textAlignment = .center
        year.attributedPlaceholder = NSAttributedString(string: "Year", attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        
        year.snp.makeConstraints { (make)->Void in
            
            make.top.equalTo(self.view.safeAreaLayoutGuide.snp.top).offset(5)
            make.centerX.equalTo(self.view.snp.centerX)
            make.width.equalTo(200)
            make.height.equalTo(50)
            
        }
        
        self.view.addSubview(month)
        month.translatesAutoresizingMaskIntoConstraints = false
        month.layer.borderWidth = 1
        month.textAlignment = .center
        month.attributedPlaceholder = NSAttributedString(string: "Month", attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        
        month.snp.makeConstraints { (make)->Void in
            
            make.top.equalTo(year.snp.bottom).offset(5)
            make.centerX.equalTo(self.view.snp.centerX)
            make.width.equalTo(200)
            make.height.equalTo(50)
            
        }
        
        self.view.addSubview(day)
        day.translatesAutoresizingMaskIntoConstraints = false
        day.layer.borderWidth = 1
        day.textAlignment = .center
        day.attributedPlaceholder = NSAttributedString(string: "Day", attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        
        day.snp.makeConstraints { (make)->Void in
            
            make.top.equalTo(month.snp.bottom).offset(5)
            make.centerX.equalTo(self.view.snp.centerX)
            make.width.equalTo(200)
            make.height.equalTo(50)
            
        }
        
        self.view.addSubview(hour)
        hour.translatesAutoresizingMaskIntoConstraints = false
        hour.layer.borderWidth = 1
        hour.textAlignment = .center
        hour.attributedPlaceholder = NSAttributedString(string: "Hour", attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        
        hour.snp.makeConstraints { (make)->Void in
            
            make.top.equalTo(day.snp.bottom).offset(5)
            make.centerX.equalTo(self.view.snp.centerX)
            make.width.equalTo(200)
            make.height.equalTo(50)
            
        }
        
        self.view.addSubview(minute)
        minute.translatesAutoresizingMaskIntoConstraints = false
        minute.layer.borderWidth = 1
        minute.textAlignment = .center
        minute.attributedPlaceholder = NSAttributedString(string: "Minute", attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        
        minute.snp.makeConstraints { (make)->Void in
            
            make.top.equalTo(hour.snp.bottom).offset(5)
            make.centerX.equalTo(self.view.snp.centerX)
            make.width.equalTo(200)
            make.height.equalTo(50)
            
        }
        
        self.view.addSubview(second)
        second.translatesAutoresizingMaskIntoConstraints = false
        second.layer.borderWidth = 1
        second.textAlignment = .center
        second.attributedPlaceholder = NSAttributedString(string: "Second", attributes: [NSAttributedString.Key.foregroundColor: UIColor.gray])
        
        second.snp.makeConstraints { (make)->Void in
            
            make.top.equalTo(minute.snp.bottom).offset(5)
            make.centerX.equalTo(self.view.snp.centerX)
            make.width.equalTo(200)
            make.height.equalTo(50)
            
        }
        
        self.view.addSubview(submit)
        submit.translatesAutoresizingMaskIntoConstraints = false
        submit.backgroundColor = .blue
        submit.setTitle("Submit", for: .normal)
        submit.addTarget(self, action: #selector(sendValues), for: .touchUpInside)
        
        submit.snp.makeConstraints { (make)->Void in
            
            make.top.equalTo(second.snp.bottom).offset(5)
            make.centerX.equalTo(self.view.snp.centerX)
            make.width.equalTo(100)
            make.height.equalTo(50)
            
        }
        
        self.view.addSubview(timeText)
        timeText.translatesAutoresizingMaskIntoConstraints = false
        timeText.layer.borderWidth = 1
        timeText.layer.borderColor = UIColor.blue.cgColor
      
        
        timeText.snp.makeConstraints { (make)->Void in
            
            make.top.equalTo(submit.snp.bottom).offset(10)
            make.centerX.equalTo(self.view.snp.centerX)
            make.leading.equalTo(self.view.snp.leading)
            make.trailing.equalTo(self.view.snp.trailing)
            make.height.equalTo(50)
            
        }
        
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(getValues), userInfo: nil, repeats: true)
        
    }
    
    @objc func sendValues() {
        
        let parameters: Parameters=[
            "year":year.text!,
            "month":month.text!,
            "day":day.text!,
            "hour":hour.text!,
            "minute":minute.text!,
            "second":second.text!
        ]
        
        Alamofire.request(URL_USER_REGISTER, method: .post, parameters: parameters).responseJSON { response in
            
            if let result = response.result.value {
                
                let jsonData = result as! NSDictionary
                print(jsonData)
                
            }
            self.timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(self.getValues), userInfo: nil, repeats: true)
        }
        
        year.text = nil
        month.text = nil
        day.text = nil
        hour.text = nil
        minute.text = nil
        second.text = nil
        
    }
     
    @objc func getValues() {
        
        let url = URL(string: "http://127.0.0.1/test7/get.php")
        var urlRequest : URLRequest = URLRequest(url: url!)
        urlRequest.httpMethod = "GET"
        URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            
            if (error == nil) {
                
                do {
                    self.mydata = try JSONDecoder().decode([myData].self, from: data!)
                    for i in self.mydata {
                        let year = i.year
                        let month = i.month
                        let day = i.day
                        let hour = i.hour
                        let minute = i.minute
                        let second = i.second
                        
                        let date = NSDate()
                        let calendar = Calendar.current
                        
                        let components = calendar.dateComponents([.hour, .minute, .second, .month, .year, .day], from: date as Date)
                        
                        let currentDate = calendar.date(from: components)
                        
                        let userCalendar = Calendar.current
                        
                        let competitionDate = NSDateComponents()
                        competitionDate.year = Int(year)!
                        competitionDate.month = Int(month)!
                        competitionDate.day = Int(day)!
                        competitionDate.hour = Int(hour)!
                        competitionDate.minute = Int(minute)!
                        competitionDate.second = Int(second)!
                        
                        let competitionDay = userCalendar.date(from: competitionDate as DateComponents)!
                        
                        let CompetitionDayDifference = calendar.dateComponents([.day, .hour, .minute, .second], from: currentDate!, to: competitionDay)
                        
                        let daysLeft = CompetitionDayDifference.day
                        let hoursLeft = CompetitionDayDifference.hour
                        let minutesLeft = CompetitionDayDifference.minute
                        let secondLeft = CompetitionDayDifference.second
                        
                        if (daysLeft == 0) && (hoursLeft == 0) && (minutesLeft == 0) && (secondLeft == 0) {
                            self.sendNotification()
                        }
                        
                        DispatchQueue.main.async {
                            //self.timeText.text = nil
                            self.timeText.reloadInputViews()
                            self.timeText.text = "\(daysLeft ?? 0) Days, \(hoursLeft ?? 0) Hrs, \(minutesLeft ?? 0) Min, \(secondLeft ?? 0) Sec Remains"
                        }
                        
                    }
                    
                } catch {
                    print("error")
                }

            }
            
        }.resume()
        
    }
    
    func requestNotificationAuthorization() {
        
        let authOptions = UNAuthorizationOptions.init(arrayLiteral: .alert, .badge, .sound)
        
        self.userNotificationCenter.requestAuthorization(options: authOptions) { (success, error) in
            if let error = error {
                print("Error: ", error)
            }
        }
    }

    func sendNotification() {
       
        let notificationContent = UNMutableNotificationContent()
           notificationContent.title = "Alert Message"
           notificationContent.body = "Time Over"
           notificationContent.badge = NSNumber(value: 3)
           
           if let url = Bundle.main.url(forResource: "dune",
                                       withExtension: "png") {
               if let attachment = try? UNNotificationAttachment(identifier: "dune",
                                                               url: url,
                                                               options: nil) {
                   notificationContent.attachments = [attachment]
               }
           }
           
           let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1,
                                                           repeats: false)
           let request = UNNotificationRequest(identifier: "testNotification",
                                               content: notificationContent,
                                               trigger: trigger)
           
           userNotificationCenter.add(request) { (error) in
               if let error = error {
                   print("Notification Error: ", error)
               }
           }
       }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        completionHandler()
    }

    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        completionHandler([.alert, .badge, .sound])
    }
    
}


