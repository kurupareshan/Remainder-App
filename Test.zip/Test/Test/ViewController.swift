//
//  ViewController.swift
//  Test
//
//  Created by kurupareshan pathmanathan on 5/15/20.
//  Copyright © 2020 kurupareshan pathmanathan. All rights reserved.
//

import UIKit
import SnapKit
import Alamofire
import UserNotifications

class ViewController: UIViewController, UNUserNotificationCenterDelegate{
    
    let button = UIButton()
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.view.backgroundColor = .white
        
        self.view.addSubview(button)
        button.translatesAutoresizingMaskIntoConstraints = false
        button.backgroundColor = .blue
        button.setTitle("Go To Inner Page", for: .normal)
        button.addTarget(self, action: #selector(presentInnerPage), for: .touchUpInside)
        
        button.snp.makeConstraints { (make)->Void in
            
            make.centerY.equalTo(self.view.snp.centerY)
            make.centerX.equalTo(self.view.snp.centerX)
            make.width.equalTo(150)
            make.height.equalTo(50)
            
        }
        
    }
    
    @objc func presentInnerPage() {
        
        let innerViewController = InnerViewController()
        self.present(innerViewController, animated: true, completion: nil)
 
    }
    
}


