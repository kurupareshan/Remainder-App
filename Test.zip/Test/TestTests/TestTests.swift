//
//  TestTests.swift
//  TestTests
//
//  Created by kurupareshan pathmanathan on 3/28/21.
//  Copyright © 2021 kurupareshan pathmanathan. All rights reserved.
//

import XCTest
@testable import Test
class TestTests: XCTestCase {
    
    let repositoryView = RepositoryView()
    let secondRepositoryView = SecondRepositoryView()
    let viewController = ViewController()
    
    func testUserName() {
        let name = repositoryView.nameLabel.text
        XCTAssertEqual(name, "Danutha Isura")
    }
    
    func testEmail() {
        let email = repositoryView.emailLabel.text
        XCTAssertEqual(email, "danu5677@yahoo.com")
    }
    
    func testEmailExist() {
        let email = repositoryView.emailLabel.text
        XCTAssertNotNil(email)
    }
    
    func testFollwersLabel() {
        let followers = repositoryView.followersLabel.text
        XCTAssertNotNil(followers)
    }
    
    func testProfileImageExist() {
        let image = repositoryView.profileImageView.image
        XCTAssertNil(image)
    }

    func testRepositoryViewsInsideTheSuperView() {
        let frame = repositoryView.bounds
        
        let emailFrame = repositoryView.emailLabel.bounds
        let value1 = frame.contains(emailFrame)
        XCTAssertTrue(value1)
        
        let awesomeView = repositoryView.awesomeView.bounds
        let value2 = frame.contains(awesomeView)
        XCTAssertTrue(value2)
        
        let modelView = repositoryView.modelView.bounds
        let value3 = frame.contains(modelView)
        XCTAssertTrue(value3)
        
        let pluginView = repositoryView.pluginView.bounds
        let value4 = frame.contains(pluginView)
        XCTAssertTrue(value4)
    }
    
    func testSecondRepositoryViewsInsideTheSuperView() {
        let frame = secondRepositoryView.bounds
        
        let modelView = secondRepositoryView.modelView.bounds
        let value1 = frame.contains(modelView)
        XCTAssertTrue(value1)
        
        let pluginView = secondRepositoryView.pluginView.bounds
        let value2 = frame.contains(pluginView)
        XCTAssertTrue(value2)
        
        let swiftDemoView = secondRepositoryView.swiftDemoView.bounds
        let value3 = frame.contains(swiftDemoView)
        XCTAssertTrue(value3)
    }
    
    func testImageExistOfSecondRepoView() {
        let image = secondRepositoryView.modelImageView.image
        XCTAssertNil(image, "Nil")
    }
    
    func testFollwersCount() {
        let follwersCount = repositoryView.followersLabel.text
        XCTAssertEqual(follwersCount, "0 followers")
    }
    
    func displayAlertMessage() {
        let alert = UIAlertController(title: "Alert",message:"Danutha Isura",
                                      preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK",style:UIAlertAction.Style.default,handler: nil))
        UIApplication.shared.keyWindow?.rootViewController?.present(alert, animated: true, completion: nil)
    }
    
    func testPresentAlertMessage() {
        self.displayAlertMessage()
        let expectation = XCTestExpectation(description: "testExample")
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0, execute: {
            XCTAssertTrue(UIApplication.shared.keyWindow?.rootViewController?.presentedViewController is UIAlertController)
            expectation.fulfill()
        })
        wait(for: [expectation], timeout: 1.5)
    }
    
}
